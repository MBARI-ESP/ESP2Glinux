/*
 * linux/fs/hfs/version.c
 *
 * Copyright (C) 1995-1997  Paul H. Hargrove
 * This file may be distributed under the terms of the GNU General Public License.
 *
 * This file contains the version string for this release.
 */

const char hfs_version[]="0.96";
