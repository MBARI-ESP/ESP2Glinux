/*
 *
 * Copyright (C) Cyclades Corporation, 1999-1999. All rights reserved.
 *
 *
 * misc.h
 * Miscelaneous system-dependent definition
 *
 * History
 * 08/17/1999 V.1.0.0 Initial revision
 *
 */

# ifdef _TSR_MISC_

# define EXTERN
# else
# define EXTERN extern
# endif

EXTERN int 	external_poll (int eventmask, int timeout);

# undef EXTERN

#define TSRDEV_VERSION "0.93"
#define TSRDEV_DATE "Wed Jan 14 19:29:42 CET 2004"
#define UNIX98
#define HAVE_DAEMON
#define LIBC "libc.so.6"
