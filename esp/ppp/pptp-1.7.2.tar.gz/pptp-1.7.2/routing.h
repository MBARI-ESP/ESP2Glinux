void routing_init(char *ip);
void routing_start();
void routing_end();
