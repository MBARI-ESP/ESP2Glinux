/* version.c ..... keep track of package version number. 
 *                 C. Scott Ananian <cananian@alumni.princeton.edu>
 *
 * $Id: version.c,v 1.3 2004/06/22 09:52:26 quozl Exp $
 */

#include "config.h"
const char * version = "pptp version " PPTP_LINUX_VERSION;
