#ifndef VSF_VERSION_H
#define VSF_VERSION_H

#define VSF_VERSION "1.2.2"

#endif /* VSF_VERSION_H */

