#ifndef VSF_TRU64_BOGONS_H
#define VSF_TRU64_BOGONS_H

/* Need dirfd() */
#include "dirfd_extras.h"

#endif /* VSF_TRU64_BOGONS_H */

