extern void sanitize_env (void);

