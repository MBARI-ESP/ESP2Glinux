extern char *myrealpath(const char *path, char *resolved_path, int m);
