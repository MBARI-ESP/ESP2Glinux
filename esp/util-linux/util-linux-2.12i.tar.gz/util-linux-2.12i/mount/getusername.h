extern char *getusername(void);
