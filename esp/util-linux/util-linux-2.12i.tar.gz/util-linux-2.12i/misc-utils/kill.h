extern int *get_pids (char *process_name, int get_all);
